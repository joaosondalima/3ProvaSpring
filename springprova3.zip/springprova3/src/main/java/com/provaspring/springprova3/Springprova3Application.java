package com.provaspring.springprova3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springprova3Application {

	public static void main(String[] args) {
		SpringApplication.run(Springprova3Application.class, args);
	}

}
